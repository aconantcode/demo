// Event Listeners 2

// First, go into the css and comment out lines 47 thru 49 to reveal the hidden content
// in the browser and compare it to the code on the html page

// Now go back to the css and un-comment out lines 47 thru 49 to hide the content again

// Line 11 constructs a variable revealBtn which contains the button with the class 
// '.reveal-btn'

const revealBtn = document.querySelector('.reveal-btn');

// Line 16 constructs a variable hiddenContent which contains a 'div' with the class 
// '.hidden-content'

const hiddenContent = document.querySelector('.hidden-content');

// Lines 24 thru 31 create a function 'revealContent' that uses an if statement to check if
// 'hiddenContent' has the class of 'reveal-btn', 'if' it does then the function removes
// the 'reveal-btn' class, 'else' the function add the 'reveal-btn' class. It works like
// a toggle. If you look at the css, any element that has both the classes of 
// .hidden-content and .reveal-btn will have its display set to 'display: block;'

function revealContent() {

    if(hiddenContent.classList.contains('reveal-btn')) {
        hiddenContent.classList.remove('reveal-btn');
    } else {
        hiddenContent.classList.add('reveal-btn');
    }
}

// Line 37 attaches an 'EventListener' to 'revealBtn', identifies that it listening
// for a 'click', and when it hears the 'click' it will trigger 
// the 'revealContent' function

revealBtn.addEventListener('click', revealContent);