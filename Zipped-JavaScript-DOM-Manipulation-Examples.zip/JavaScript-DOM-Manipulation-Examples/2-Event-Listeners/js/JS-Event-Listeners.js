// Event Listeners

// First, go to the html code and comment out line 18, and un-comment out line 19 to 
// add the 'onclick' function directly into the html code

// Line 8 constructs the variable 'buttonTwo' that contains '.btn-2' element

const buttonTwo = document.querySelector('.btn-2');

// Lines 12 thru 14 creates the function 'alertBtn' to execute an 'alert'

function alertBtn () {
    alert('I am listening too');
}

// Line 19 attaches an 'EventListener' to buttonTwo, identifies that it listening
// for a 'click', and when it hears the 'click' it will trigger the 'alertBtn' function

buttonTwo.addEventListener('click', alertBtn);

// Mouseover

// Line 25 constructs the variable 'newBGColor' that contains '.btn-3' element

const newBGColor = document.querySelector('.btn-3');

// Lines 29 thru 31 creates the function 'changeBGColor' to change the 'backgroundColor'

function changeBGColor() {
    newBGColor.style.backgroundColor = 'rgba(0, 0, 0, 80%)';
}

// Line 37 attaches an 'EventListener' to 'buttonTwo', identifies that it listening
// for a 'mouseover', and when it hears the 'mouseover' it will trigger 
// the 'changeBGColor' function

newBGColor.addEventListener('mouseover', changeBGColor);