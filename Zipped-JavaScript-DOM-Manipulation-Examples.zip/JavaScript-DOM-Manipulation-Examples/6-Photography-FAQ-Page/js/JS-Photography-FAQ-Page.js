// Photography Exposure Settings FAQ
// 
// Variables
// 
// Go Check out the css code first, read the comment that starts on css line 38
// Line 8 constructs a variable 'faq' which is an array of all the html elements
// with the class of 'content-container'

const faq = document.getElementsByClassName('content-container');

// un-comment out line 13 and save to log the 'faq' array

console.log(faq);

// comment out line 13 and save

// Staring on line 19 we are using a 'for loop' to '.addEventListener' to each html item
// within the variable array 'faq' which contains all the html elements with the class
// of 'content-container'. When a 'click' is registered as function is triggered, the function
// is checking to see if the element that was 'clicked' has the class of 'active'. The
// '.toggle' method will add the class of 'active' if it isn't already there, and remove 
// the class of 'active' if it is already there. Any element with both the classes of 
// '.content-container' and '.active' will becomw visible

for(i = 0; i < faq.length; i++) {
    faq[i].addEventListener('click', function() {
        this.classList.toggle('active');
    })
};

// With just 6 lines of js code we can create an endless list to FAQ question and answers