// Event Listeners 3

// Event Delegation

// Event Delgation allows users to append a SINGLE event listener to a parent
// element that adds it to all of its present AND future descendsnts that
// match the selector

// (property) Event.target: EventTarget | null
// Returns the object to which event is dispatched (its target).
// (parameter) e: Event

// document.querySelector('#sports').addEventListener('click', function(e)...
// this is a shortcode method for condensing the construction of a variable,
// constructing the function, and assign an event listener

// Lines 21 thru 30 are targeting the 'id' of '#football' as a button. When 'clicked' the 
// function below will 'console.log('football is clicked');' and 'capitalize' 
// the first letter of football

document.querySelector('#football').addEventListener('click', function(e) {
    console.log('football is clicked');

    const target = e.target;

    if(target.matches('li')) {
        target.style.textTransform = "capitalize";
    }
    console.log(target);
})

// We could make a separate query for each 'li' item, but that would require 5 times
// the amount of code above and would add any functionality to future add 'li' items
// unless even more code was added.

// Comment out lines 21 thru 30 and save the change

// We can drastically reduce the amount of code required by attaching the functionality
// to the parent 'ul' element

// The code below queries for the 'id' of "#sports". The code on lines 46 thru 54
// should add the console.log and capitalization to which ever button is clicked
// un-comment out lines 45 thru 53 and save the change and test the functionality

// document.querySelector('#sports').addEventListener('click', function(e) {
//     const target = e.target;

//     console.log(e.target.getAttribute('id') + ' is clicked');

//     if(target.matches('li')) {
//         target.style.textTransform = "capitalize";
//     }
// })

// Add list item

// Because we attached the functionality to the 'ul', if we add a new 'li' it should
// also have the same functionality

// un-comment out line 63 to create the variable 'sports' to contain the 'ul' with 
// the 'id' of '#sports'

// const sports = document.querySelector('#sports');

// un-comment out line 67 to create a new variable 'newSport' to create a new 'li' element

// const newSport = document.createElement('li');

// un-comment out line 71 to the variable 'newSport' the innerText of 'tennis'

// newSport.innerText = 'tennis';

// un-comment out line 75 to the variable 'newSport' the an 'id' of 'tennis'

// newSport.setAttribute('id', 'tennis');

// un-comment out line 80 to the 'newSport' 'li' to the 'ul', then test the functionality
// of the new 'li' item

// sports.appendChild(newSport);