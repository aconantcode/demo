// Selecting DOM Elements

// Using This File: All sections except the frist one is 
// commentted out. Using the keyboard shortcut ctl+/ on PC
// cmd+/ on MAC, un-comment out each section as you go. It's
// helpful to comment out there various console.log() lines
// as you progress through the demo to keep your console
// window in your browser's inspector clear and easy to
// read/understand 

// GetElementById()
// This first line creates a vartiable called 'title' and gives it the value of 
// the id 'main-heading' which includes all the attributes, values. and properties 
// of 'main-heading'. But, this is just creating the variable, it is not proforming
// any function with it yet. un-comment out line 17 and save the change

// const title = document.getElementById('main-heading');

// un-comment out line 22 and save the change, this will log what you have 
// collected in your variable

// console.log(title);

// un-comment out line 27 and save the change, this line uses the 
// variable 'title' to change the style of its color property to yellow,
// if you look in the element tab in the inspector and drill down to the h1 line
// you'll see the style has been added intp the h1 line
// <h1 id="main-heading" style="color: yellow;">5 Highest-Grossing Movie Franchises</h1>

// title.style.color = 'yellow';

// un-comment out line 36 and save the change, this line show how you can
// access the properties of the elements you assign to a variable, in this case,
// the text within 'main-heading' the id assigned to the variable 'title'

// console.log(title.innerText);

// GetElementByClassName()

// Comment out your previous console.logs and save the change to clear the console

// un-comment out line 46 and save the change, this line creates a vartiable called 
// 'listItems' and gives it the value of the class 'list-items' which includes
// all the attributes, values. and properties of 'list-items'.

// const listItems = document.getElementsByClassName('list-items');

// un-comment out line 51 and save the change, this will log what you have 
// collected in your variable

// console.log(listItems);

// The console.log should return the following:
// 
// HTMLCollection(5) [li.list-items, li.list-items, li.list-items, li.list-items, li.list-items]
// 
// And when you click on the triangle preceeding 'HTMLCollection(5)', you should see:
// 
// 0: li.list-items
// 1: li.list-items
// 2: li.list-items
// 3: li.list-items
// 4: li.list-items
// length: 5
// [[Prototype]]: HTMLCollection
// 
// 'HTMLCollection(5)' shows five items consisting of the element-type.class, and these items
// are in brackets. When you open 'HTMLCollection(5)' you see the items numbered or indexed
// 0 to 4. The variable you have created has collected all the elements of the class
// 'list-items' and has create an array. The variable 'listItems' is an array and can be
// treated or acted upon as such.

// Let's try assigning a color to the variable 'istItems' to change all the franchise
// names to green. Un-comment out line 77 and save the change, this uses the same method
// we used above.

// listItems.style.color = 'green';

// Line 77 causes an error because 'listItems' is an array, it has multiple items, and
// our code doesn't specify which item to modify. Comment out line 77 and save to clear 
// the error

// un-comment out line 87 and save the change, we know 'listItems' is an array with items
// indexed 0 to 4, using brackets and an cooresponding index number we can modify items in
// the array

// listItems[0].style.color = 'green';

// 'Marvel Cinematic Universe' should now be green. Try changing the index number in the
// brackets on line 87 then save, and see how you can modify and item you wish.

// Now, we could use five lines of code to change all the items like:
// 
// listItems[0].style.color = 'green';
// listItems[1].style.color = 'green';
// listItems[2].style.color = 'green';
// listItems[3].style.color = 'green';
// listItems[4].style.color = 'green';
// 
// But, the longer the code, the slower it runs. In this case we can use
// one for loop to change all the franchise names
// Comment out line 87, then un-comment out lines 104 thru 106 and save the change

// for(i = 0; i < listItems.length; i++) {
//     listItems[i].style.color = 'green';
// }

// getElementByTagName()

// un-comment out line 114 and save the change, this line creates a vartiable called 
// 'listByTag' and gives it the value of the class 'li' which includes
// all the attributes, values. and properties of 'li'.

// const listByTag = document.getElementsByTagName('li');

// un-comment out line 119 and save the change, this will log what you have 
// collected in your variable

// console.log(listByTag);

// Notice that 'console.log(listByTag);' returns an identical result 
// to 'console.log(listItems);'. Why? Click on the 'Elements' tab in the 
// inspector, and open up the 'ul' to reveal all the items within.
// Each item is an 'li' with a class of 'list-items', all the items in the 'ul'
// match the criteria of both selector methods.


// querySelector() selects the first instance of the selector specified

// Comment out lines 51 and 119 and save to clear the console window.
// un-comment out line 136 and save the change, this line creates a vartiable called 
// 'queryList' and gives it the value of the class 'li' which includes
// all the attributes, values. and properties of 'li', but only the first 'li' encountered
// in the HTML

// const queryList = document.querySelector('li');

// un-comment out line 140 and save the change, this will log what you have 
// collected in your variable

// console.log(queryList);

// console.log(queryList); returns: <li class="list-items" style="color: green;">Marvel Cinematic Universe</li>
// It returns the first 'li' it encounters.

// un-comment out line 149 and save the change, this will log the 'innerText' 
// of your variable

// console.log(queryList.innerText);


// querySelectorAll()

// Comment out lines 141 and 149 and save to clear the console window.
// un-comment out line 159 and save the change, this line creates a vartiable called 
// 'queryListAll' and gives it the value of the class 'li' which includes
// all the attributes, values. and properties of 'li'

// const queryListAll = document.querySelectorAll('li');

// un-comment out line 164 and save the change, this will log what you have 
// collected in your variable

// console.log(queryListAll);

// We've seen this before, it's an array of all the 'li' items
// un-comment out line 170 and save the change, console.log(queryListAll[0].innerText);
// should return 'Marvel Cinematic Universe'

// console.log(queryListAll[0].innerText);

// Try changing the number in the brackets on line 170 to iterate through all the 'li' items,
// remeber to save each time you update the number.

// To list the innerText for all the 'li' items we can use another 'for loop'
// Comment out lines 164 and 170, and then un-comment out lines 178 thru 180 and save

// for(i = 0; i < queryListAll.length; i++) {
//     console.log(queryListAll[i].innerText);
// }

// Creating Elements

// To create a new 'li' and add it to the 'ul', we first need to construct a variable that
// contains the 'ul' element
// un-comment out line 190 and save the change, this line creates a vartiable called 
// 'ul' and gives it the value of the element 'ul' which includes
// all the attributes, values. and properties of 'ul'

// const ul = document.querySelector('ul');

// Using the method 'document.createElement()', we can create an instance of the element 
// for the specified tag we include in the parenthesis

// un-comment out line 199 and save the change, this line creates a vartiable called 
// 'li' and creates a new 'li' element. The 'li' element is created without any default id
// class, and with no innerText

// const li = document.createElement('li');

// Adding Elements

// To add our new 'li' to the existing 'ul', un-commet out line 205 and save the change

// ul.append(li);

// You can see in the browser that a new 'li' without text has been added to the bottom
// of the franchise names. If you click on the 'Elements' tab in the inspector and open the 
// 'ul', you can see the empty '<li></li>' is now added

// un-comment out line 213 and save the change,

// console.log(listItems);

// notice we are not seeing the new 'li' returned by console.log(listItems);
// This is because the variable 'listItems' is and array of items that have the
// class of 'list-items'.
// Currently, our new 'li' hasn't been assigned that class

// Modifying text

// Let's add some text to our new 'li'. Just like we can use .innerText to access an elements
// innerText, we can also use it to help us assign innerText
// un-comment out line 227 and save the change, this line is setting the innerText to
// 'The Avengers'

// li.innerText = 'The Avengers';

// Now we can see that 'The Avengers' has been added to the last 'li' in our 'ul'

// Modifying Attributes and Classes

// In the 'Elements' tab in the inspector, open up the 'ul' so you can see our new 'li'
// with the text 'The Avengers' and click on the line. Sometimes when you save the 'ul' can
// close up, and by clicking on the 'li' we want to watch, the 'ul' shouldn't close up
// when we save

// Let's test adding an 'id' to our new 'li'. We will use the method
// 'setAttribute('id', 'id-name');' which needs us to specify the attribute and name
// the attribute.

// un-comment out line 245 and save the change, this line will add an 'id' of 'id-example'
// to our new 'li'

// li.setAttribute('id', 'id-example');

// In the 'Elements' tab in the inspector, we can now see that the last 'li' has
// an 'id' of 'id-example'

// To remover the id we use the method 'removeAttribute('id');'

// un-comment out line 245 and save the change, this line will remove the 'id' of 'id-example'
// from our new 'li'

// li.removeAttribute('id');


// We can use the method 'classList.add('class');' to add the class of 'list-items' to
// our 'li', un-comment out line 227 and save the change

// li.classList.add('list-items');

// If we look at the 'Elements' tab in the inspector we can see the class of 'list-items'
// is now added to the last 'li', but it doesn't have the 'style="color: green;"'.
// The 'for loop' we used to set 'style="color: green;"' is way back up on line 104, it runs
// before the new 'li' gets created.

// Comment out lines 104 thru 106, and then un-comment out lines 272 thru 274 and save
// by placing the 'for loop' after the creation of the new 'li', the new 'li' should now get
// 'style="color: green;"'

// for(i = 0; i < listItems.length; i++) {
//     listItems[i].style.color = 'green';
// }

// Let's add another class to our new 'li'. In the css there is a class 'list-items-alt'
// which sets the font-weight to 700. un-comment out line 280 and save the change, this line
// will add the new class to the 'li'

// li.classList.add('list-items-alt');


// To remove a class we can use the method 'classList.remove('class');'
// un-comment out line 287 and save the change, this line will remove the 'list-items-alt'
// class from the 'li'

// li.classList.remove('list-items-alt');

// Traversing the DOM

// Comment out lines 178 thur 180 and line 213 and save to clear the console window.

// Parent Nodes and Elements

// un-comment out lines 297 thru 300 and save

// console.log(ul);
// console.log(ul.parentNode);
// console.log(ul.parentNode.parentNode);
// console.log(ul.parentNode.parentNode.parentNode);

// Looking at the HTML you can confirm that the parent of the 'ul' is a 'div' with the
// class of 'container', which has a parent of 'body', whose parent is 'html'

// un-comment out lines 307 thru 310 and save

// console.log(ul);
// console.log(ul.parentElement);
// console.log(ul.parentElement.parentElement);
// console.log(ul.parentElement.parentElement.parentElement);

// Both logging for 'Nodes' and 'Elements' here return the same list, but there is a 
// difference between 'Nodes' and 'Elements'

// Comment out lines 297 thur 300 and lines 307 thur 310 and save to clear the console window.

// un-comment out line 320 and save the change, this line create the variable 'html' 
// and assigns it the first element in the document

// const html = document.documentElement;

// un-comment out lines 324 and 325 and save the change,

// console.log(html.parentNode);
// console.log(html.parentElement);

// You can see in the console window that html has a parent node but not a parent element

// Child Node

// Comment out lines 320 and lines 324 and 325 and save to clear the console window.

// un-comment out line 335 and save the change,

// console.log(ul);

// In the console the 'ul' is logged and you can open it to see its contents

// Comment out lines 335 and un-comment out line 341 and save the change,

// console.log(ul.childNodes); 

// Logging all the 'childNodes' returns an array with 12 items. Open the array and you see
// a 'text' item preceeding each 'li.list-items' item. The '0: text' refers to the 
// indentation on the line in the html

// un-comment out lines 349 and 350 save the change,

// console.log(ul.firstChild);
// console.log(ul.lastChild);

// un-comment out line 354 and save the change,

// console.log(ul.children);

// .children is looking for Elements not Nodes and return a just the 'li.list-items' items.

// un-comment out lines 360 and 361 and save the change,

// console.log(ul.firstElementChild);
// console.log(ul.lastElementChild);

// Here the difference between 'Nodes' and 'Elements' is much clearer. Using 'Elements'
// returns results of content, and 'Nodes' returns results of structure and content

// Comment out lines 341, 349, 350, 354, 360, and 361 and save to clear the console window.

// un-comment out lines 370 thru 372 and save the change

// console.log(ul.innerText);
// console.log(ul.childNodes.innerText);
// console.log(ul.children[0].innerText);

// Here we can see that logging 'console.log(ul.innerText);' returns the text from
// all the 'li' items in the 'ul'
// 'console.log(ul.childNodes.innerText);' is undefined because 'ul.childNodes' is an
// array of all the 'li' items
// But we can iterate though the 'li' items by adding the index notation in brackets to 
// the console.log as above: 'console.log(ul.children[0].innerText);'

// Time to try some 'for loops', comment out lines 370 thru 372 and save,
// un-comment out lines 384 thru 386 to log all the 'childNodes'

// for(i = 0; i < ul.childNodes.length; i++) {
//     console.log(ul.childNodes[i]);
// }

// un-comment out lines 391 thru 393 to log all the 'children' (Elements) and compare
// the two lists, you'll have to increase the size of your console window to see both

// for(i = 0; i < ul.children.length; i++) {
//     console.log(ul.children[i]);
// }

// Sibling Node

// Comment out lines 384 thru 386 and lines 391 thru 393 and save to clear the console window.
// un-comment out lines 400 and 401 and save

// console.log(ul.nextElementSibling);
// console.log(ul.previousElementSibling);

// 'console.log(ul.nextElementSibling);' returns 'null' and looking at the html we can see
// that in fact 'ul' does not have a next sibling, but 'lu' does have a previous sibling and
// 'console.log(ul.previousElementSibling);' returns the 'h1' element.